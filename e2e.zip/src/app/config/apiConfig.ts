export class apiConfig {
    public static readonly loginUrl = "Login";
   
  }